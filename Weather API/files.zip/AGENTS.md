# AGENTS.md — Weather & Outfit App

This file defines instructions, constraints, and context for any AI coding agent working on this project.

---

## Project Overview

This is a mobile-first weather app that recommends outfits based on live weather data. It is built with **vanilla HTML, CSS, and JavaScript only** — no frameworks, no libraries, no build tools. Every feature must be implemented within these three file types.

---

## Absolute Constraints

- ❌ Do NOT use React, Vue, Svelte, or any JS framework
- ❌ Do NOT use TypeScript
- ❌ Do NOT use npm, Vite, Webpack, or any build tool
- ❌ Do NOT add any external libraries (no Lodash, no Axios, no Chart.js, etc.)
- ❌ Do NOT use a backend or server-side code
- ✅ Use only `index.html`, `style.css`, and `script.js`
- ✅ All API calls must use the native `fetch()` API
- ✅ All code must run directly in the browser by opening `index.html`

---

## File Responsibilities

### `index.html`
- App structure and semantic markup
- Links to `style.css` and `script.js`
- Contains all screen sections: search screen, weather screen
- Uses semantic HTML5 elements (`<main>`, `<section>`, `<header>`, etc.)

### `style.css`
- All visual styling, layout, and animations
- CSS custom properties (variables) for the dynamic theme system
- Mobile-first using `min-width` media queries for desktop breakpoints
- Theme classes (e.g. `.theme-sunny`, `.theme-rainy`, `.theme-night`) applied to `<body>` by JS
- No external fonts loaded via JS — use Google Fonts `<link>` in HTML if needed

### `script.js`
- All application logic
- Geocoding API calls (city search)
- Forecast API calls (weather data)
- Outfit recommendation logic (hardcoded decision tree)
- Dynamic theme switching (weather + time of day)
- °C / °F toggle logic
- DOM manipulation and event listeners
- No ES modules — use a single script file with plain functions

---

## APIs

### Geocoding (City Search)
- **URL:** `https://geocoding-api.open-meteo.com/v1/search`
- **Key params:** `name` (search string), `count` (number of results, suggest 5), `language=en`
- **Purpose:** Validate that a city exists and get its coordinates
- **Usage:** Called on input with a short debounce (300ms); results shown as a dropdown

### Weather Forecast
- **URL:** `https://api.open-meteo.com/v1/forecast`
- **Key params:** `latitude`, `longitude`, `current`, `hourly`, `daily`, `timezone=auto`
- **Requested variables:**
  - `current`: `temperature_2m`, `weathercode`, `windspeed_10m`, `precipitation_probability`
  - `hourly`: `temperature_2m`, `weathercode`, `precipitation_probability`
  - `daily`: `temperature_2m_max`, `temperature_2m_min`, `sunrise`, `sunset`, `uv_index_max`
- **Units:** Default to `temperature_unit=celsius`; swap to `fahrenheit` when toggled

---

## Design System

### Vibe
Soft and friendly. Approachable for all ages. Nothing clinical or overly technical.

### Typography
- **Font:** Nunito or Poppins (rounded, friendly)
- Load via Google Fonts `<link>` in `index.html`
- Headings: bold weight; body: regular; small labels: light

### Colour & Theming
The `<body>` receives a theme class based on **weather condition + time of day**. CSS variables update accordingly. Example classes:

| Class | Condition |
|-------|-----------|
| `.theme-sunny-day` | Clear sky, daytime |
| `.theme-sunny-morning` | Clear sky, sunrise hour |
| `.theme-cloudy-day` | Overcast, daytime |
| `.theme-rainy` | Rain or drizzle, any time |
| `.theme-stormy` | Thunderstorm |
| `.theme-night` | Any condition, night hours |
| `.theme-sunset` | Any condition, sunset hour |
| `.theme-snow` | Snow or sleet |

Each theme class sets at minimum:
- `--bg-gradient`: background gradient
- `--card-bg`: card background colour
- `--text-primary`: main text colour
- `--text-secondary`: muted text colour
- `--accent`: highlight/icon colour

### Layout
- Mobile-first, single column
- Card-based: each info block lives in a rounded card with soft shadow
- Outfit recommendation is the **hero** — large, prominent, top of the weather screen
- Hourly forecast: horizontally scrollable strip of cards
- Extra info: smaller cards in a 2-column grid below the hourly strip

### Imagery
- Weather icons: illustrated/hand-drawn SVG style
- Embed SVG icons inline in HTML or reference from a local `/icons/` folder
- Do not use emoji as primary weather icons

---

## Outfit Recommendation Logic

The recommendation is hardcoded in `script.js` using a decision tree. It must consider:

1. **Temperature** (°C): `< 5`, `5–12`, `13–18`, `19–24`, `25+`
2. **Precipitation probability**: `< 20%` (dry), `20–60%` (possible), `> 60%` (likely)
3. **Wind speed** (km/h): `< 20` (calm), `20–40` (breezy), `> 40` (windy)
4. **Time of day**: morning, afternoon, evening (temperature may drop — flag this)

Output is a short, friendly sentence or two. Examples:
- "A light t-shirt and shorts will do. Don't forget sunscreen!"
- "Take a jacket — it's breezy out there today."
- "Rain is likely. Pack an umbrella and wear waterproof shoes."
- "Bundle up! A heavy coat, scarf, and gloves are a must."

---

## Screen Flow

```
[Search Screen]
  └── User types city name
  └── Dropdown appears with verified results
  └── User selects a city
        ↓
[Weather Screen]
  └── Hero: Outfit recommendation
  └── Current temp + condition + weather icon
  └── Daily high / low  |  °C/°F toggle
  └── Hourly forecast strip (scrollable)
  └── Extra info cards (wind, humidity, UV, sunrise/sunset)
```

---

## Coding Style

- Use `const` and `let` — no `var`
- Use `async/await` for all fetch calls with `try/catch` error handling
- Add a comment above every function explaining what it does
- Keep functions small and single-purpose
- Use descriptive variable names (e.g. `precipitationProbability`, not `pp`)
- All DOM element references at the top of `script.js` as `const` declarations

---

## Error Handling

- If geocoding returns no results: show "No cities found. Try a different search."
- If the forecast API fails: show "Couldn't load weather. Please try again."
- Never show a blank or broken screen — always show a user-friendly message

---

## Accessibility

- All interactive elements must be keyboard accessible
- Colour contrast must meet WCAG AA minimum
- Icons must have `aria-label` or accompanying visible text
- Search input must have a visible `<label>`
