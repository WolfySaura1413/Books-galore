# 🌤️ Weather & Outfit App

A soft, friendly weather app that tells you what to wear. Built mobile-first, designed for everyone.

---

## What It Does

This app combines real-time weather data with practical outfit recommendations. You search for any city in the world, get a live weather report, and the app tells you what to wear based on the current conditions — no guesswork needed.

---

## Tech Stack

- **HTML** — structure and layout
- **CSS** — styling, animations, and dynamic theming
- **JavaScript** — all logic, API calls, and interactivity
- No frameworks. No build tools. No dependencies. Just three files.

---

## Feature Walkthrough

### 1. 🔍 City Search
The user opens the app and is greeted by a search bar. As they type a city name, the app queries the **Open-Meteo Geocoding API** (`https://geocoding-api.open-meteo.com/v1/search`) in real time and displays a dropdown of matching, verified real-world locations (e.g. "Paris, Île-de-France, France" vs "Paris, Texas, US"). The user taps their city and the app proceeds.

### 2. 🌡️ Weather Report
Once a city is selected, the app fetches live weather data from the **Open-Meteo Forecast API** (`https://api.open-meteo.com/v1/forecast`) using the city's coordinates. The following data is retrieved:
- Current temperature (shown in °C by default, toggleable to °F)
- Current weather condition (e.g. clear sky, rain, thunderstorm)
- Wind speed
- Precipitation probability
- Hourly forecast for the rest of the day
- Daily high and low

### 3. 👗 Outfit Recommendation (Hero Section)
At the top of the weather screen — the most prominent part of the UI — the app displays a hardcoded outfit recommendation based on a combination of:
- Temperature range
- Precipitation probability
- Wind speed
- Time of day

Examples:
- ☀️ 25°C+, low wind, no rain → "Light t-shirt and shorts. Sunglasses recommended."
- 🌧️ Rain likely → "Waterproof jacket and closed shoes. Bring an umbrella."
- 🥶 Under 5°C → "Heavy coat, scarf, and gloves. Layer up."
- 🌬️ High wind, mild temp → "A windproof layer over your outfit."

### 4. 📅 Hourly Forecast Strip
Below the current conditions, a horizontally scrollable strip shows the hour-by-hour forecast for the rest of the day — temperature and a small weather icon for each hour.

### 5. 📊 Extra Info Cards
Below the hourly strip, bite-sized cards display additional useful info: UV index, humidity, wind speed, and sunrise/sunset times. Cards are arranged to flow naturally based on available space.

### 6. 🌗 Dynamic Theme
The app's background, colour palette, and mood shift automatically based on:
- **Weather condition** — warm and golden for sunny, cool and grey for overcast, deep blue for rain, etc.
- **Time of day** — soft sunrise tones in the morning, bright midday palette, warm amber at sunset, deep navy at night.

### 7. 🌡️ °C / °F Toggle
A small toggle in the corner lets the user switch between Celsius and Fahrenheit at any point. All displayed temperatures update instantly without a re-fetch.

---

## APIs Used

| API | Purpose | URL |
|-----|---------|-----|
| Open-Meteo Geocoding | City search & validation | `https://geocoding-api.open-meteo.com/v1/search` |
| Open-Meteo Forecast | Live weather data | `https://api.open-meteo.com/v1/forecast` |

Both APIs are free, require no authentication, and return JSON.

---

## Project Structure

```
weather-app/
├── index.html       # App structure and layout
├── style.css        # All styles, themes, and animations
└── script.js        # All logic — API calls, outfit logic, theme switching
```

---

## Licence
Open for personal and educational use.
